# SAAD SPICES – Android

تطبيق SAAD SPICES لإدارة الماركتات والتشييك الأسبوعي والحسابات المالية.

## بناء APK تلقائياً عبر GitHub Actions

1. أنشئ مستودعاً جديداً على GitHub.
2. ارفع جميع ملفات هذا المشروع إلى المستودع، بحيث يكون `.github/workflows/build-apk.yml` في المسار الصحيح.
3. من GitHub افتح تبويب **Actions**.
4. اختر **Build SAAD SPICES APK**.
5. اضغط **Run workflow** (يمكن أيضاً أن يبدأ البناء تلقائياً عند رفع Commit إلى `main` أو `master`).
6. بعد انتهاء البناء، افتح تشغيل الـWorkflow الناجح.
7. من قسم **Artifacts** حمّل `SAAD-SPICES-APK`.
8. فك الضغط عن الملف وستجد `SAAD-SPICES.apk` جاهزاً للتثبيت على هاتف Android.

## ملاحظات
- البناء الحالي Debug APK ومناسب للتثبيت والاستخدام الشخصي.
- يتم استخدام Java 17 وGradle 8.7 وAndroid Gradle Plugin 8.5.2.
- لا يحتاج GitHub Actions إلى Android Studio على جهازك.

## تسجيل البريد الإلكتروني والمزامنة السحابية

تمت إضافة تسجيل/دخول بالبريد الإلكتروني، واستعادة كلمة المرور، ومزامنة بيانات الماركتات والحسابات مع Firebase Firestore. هذا يسمح باستعادة البيانات بعد حذف التطبيق أو عند استخدام جهاز آخر بنفس الحساب.

### إعداد Firebase قبل أول بناء

1. أنشئ مشروعاً في Firebase.
2. فعّل **Authentication > Sign-in method > Email/Password**.
3. أنشئ قاعدة **Cloud Firestore**.
4. أضف تطبيق Web في مشروع Firebase وانسخ إعداداته إلى:
   `app/src/main/assets/firebase-config.js`
5. ضع قواعد Firestore التالية:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

> لا تضع Service Account أو مفاتيح خاصة داخل المشروع. إعدادات Firebase Web/API ليست بديلاً عن قواعد Firestore؛ الحماية الفعلية للبيانات تعتمد على Authentication وSecurity Rules.

## الميزات الجديدة

- تسجيل حساب بالبريد الإلكتروني وتسجيل الدخول والخروج.
- إعادة تعيين كلمة المرور عبر البريد.
- مزامنة واستعادة بيانات التطبيق عبر Firebase.
- الفاتورة تحسب تلقائياً: **عدد القطع × سعر القطعة الواحدة = إجمالي الفاتورة**.
- عرض قيمة الفاتورة الإجمالية ضمن الحسابات.
- حذف أي ماركت مباشرة من قائمة الماركتات أو من شاشة التعديل.
- أيقونة التطبيق خضراء مكتوب فيها **SAAD** باللون الأبيض.

### إعداد GitHub Actions لـ Firebase

لجعل البناء من GitHub يستخدم إعداد Firebase، أضف هذه القيم كـ **Repository Secrets**:

- `FIREBASE_API_KEY`
- `FIREBASE_AUTH_DOMAIN`
- `FIREBASE_PROJECT_ID`
- `FIREBASE_STORAGE_BUCKET`
- `FIREBASE_MESSAGING_SENDER_ID`
- `FIREBASE_APP_ID`

الـWorkflow سيضعها تلقائياً في `firebase-config.js` أثناء البناء، ولن تحتاج إلى حفظها داخل Git.


## GitHub Actions (محدث)

تم تحديث سير العمل ليستخدم إصدارات GitHub Actions المتوافقة مع Node.js 24، ومنها `actions/checkout@v6` و`actions/setup-java@v6` و`android-actions/setup-android@v4` و`actions/upload-artifact@v6`. كما تمت إضافة خطوة تحقق من Java وGradle ورفع تقارير البناء عند الفشل.

التحذير الظاهر في GitHub عن Node.js 20 ليس هو سبب فشل APK بحد ذاته؛ علامة X الحمراء تعني أن خطوة بناء Gradle فشلت. النسخة الجديدة تعرض سجل البناء بشكل أوضح وترفع تقارير الخطأ تلقائياً.
