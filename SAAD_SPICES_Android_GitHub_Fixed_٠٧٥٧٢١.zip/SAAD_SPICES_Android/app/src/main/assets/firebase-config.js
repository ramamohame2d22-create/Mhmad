// إعداد Firebase — ضع بيانات مشروعك هنا قبل البناء.
// لا تضع Service Account أو أي مفتاح سري هنا. إعدادات Web API يمكن أن تكون ظاهرة في التطبيق.
window.FIREBASE_CONFIG = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_FIREBASE_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};
